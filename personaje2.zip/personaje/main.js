import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
 
const escena = new THREE.Scene();
escena.background = new THREE.Color(0x0f1420);
 
// "let" porque en el paso 7 cambiaremos de cámara
let camara = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 100);
camara.position.set(6, 5, 10);

 
const renderizador = new THREE.WebGLRenderer({ antialias: true });
renderizador.setSize(innerWidth, innerHeight);
document.body.appendChild(renderizador.domElement);
 
const controles = new OrbitControls(camara, renderizador.domElement);
controles.target.set(0, 1.5, 0);

// Luces: sin luz, los materiales "Standard" se verían negros
escena.add(new THREE.AmbientLight(0xffffff, 0.8));
const luz = new THREE.DirectionalLight(0xffffff, 2);
luz.position.set(5, 10, 7);
escena.add(luz);
 
// Plano cartesiano: X rojo, Y verde, Z azul + cuadrícula en el piso (XZ)
escena.add(new THREE.AxesHelper(5));
escena.add(new THREE.GridHelper(20, 20, 0x55607a, 0x2a3348));
 
// Datos que se muestran en el panel de la esquina
const datos = {};
const panel = document.getElementById('panel');
function vec(v) {
  return `(${v.x.toFixed(1)}, ${v.y.toFixed(1)}, ${v.z.toFixed(1)})`;
}
 
// Lista de animaciones: cada paso agregará la suya con animaciones.push()
const animaciones = [];
const reloj = new THREE.Clock();
 
renderizador.setAnimationLoop(() => {
  const t = reloj.getElapsedTime(); // segundos desde que inició
  animaciones.forEach((animar) => animar(t));
  const lineas = Object.entries(datos).map(([k, v]) => `${k}: ${v}`);
  panel.textContent = lineas.join('\n');
  controles.update();
  renderizador.render(escena, camara);
});
 
addEventListener('resize', () => {
  camara.aspect = innerWidth / innerHeight;
  camara.updateProjectionMatrix();
  renderizador.setSize(innerWidth, innerHeight);


});
const gris = new THREE.MeshStandardMaterial({ color: 0xffffff }); 
const azul = new THREE.MeshStandardMaterial({ color: 0x00ff00 }); 
const rojo = new THREE.MeshStandardMaterial({ color: 0xffff00 }); 
const negro = new THREE.MeshStandardMaterial({ color: 0x111111 }); 
 
const robot = new THREE.Group();
escena.add(robot);
 
// cuerpoRobot: guarda todas las piezas 
const cuerpoRobot = new THREE.Group();
robot.add(cuerpoRobot);
 
// Crea una pieza, la coloca en (x, y, z) y la agrega a su "padre"
function pieza(geometria, material, x, y, z, padre = cuerpoRobot) {
  const malla = new THREE.Mesh(geometria, material);
  malla.position.set(x, y, z);
  padre.add(malla);
  return malla;
}
 
// --- Superficies PLANAS (cajas) ---
pieza(new THREE.BoxGeometry(0.4, 0.8, 0.4), gris, -0.3, 0.4, 0); // pierna izq.
pieza(new THREE.BoxGeometry(0.4, 0.8, 0.4), gris, 0.3, 0.4, 0);  // pierna der.
const torso = pieza(new THREE.BoxGeometry(1.4, 1.2, 0.8), azul, 0, 1.4, 0);
const cabeza = pieza(new THREE.BoxGeometry(1, 0.8, 0.8), gris, 0, 2.4, 0);
 
// --- Superficies CURVAS (esferas, cilindros, TORO)
// Las piezas de la cara usan "cabeza" como padre: se mueven con ella
pieza(new THREE.SphereGeometry(0.12, 16, 8), negro, -0.22, 0.1, 0.41, cabeza);
pieza(new THREE.SphereGeometry(0.12, 16, 8), negro, 0.22, 0.1, 0.41, cabeza);
const boca = pieza(new THREE.TorusGeometry(0.15, 0.04, 8, 16, Math.PI),
  negro, 0, -0.15, 0.41, cabeza);
boca.rotation.z = Math.PI; 
pieza(new THREE.CylinderGeometry(0.03, 0.03, 0.4, 8), negro, 0, 0.6, 0, cabeza);
pieza(new THREE.SphereGeometry(0.1, 16, 8), rojo, 0, 0.85, 0, cabeza); 
 
const hombroIzq = new THREE.Group();
hombroIzq.position.set(-0.85, 1.9, 0);
cuerpoRobot.add(hombroIzq);
pieza(new THREE.CylinderGeometry(0.15, 0.15, 1, 16), gris, 0, -0.5, 0, hombroIzq);
pieza(new THREE.SphereGeometry(0.2, 16, 8), rojo, 0, -1.05, 0, hombroIzq);
 
const hombroDer = new THREE.Group();
hombroDer.position.set(0.85, 1.9, 0);
cuerpoRobot.add(hombroDer);
pieza(new THREE.CylinderGeometry(0.15, 0.15, 1, 16), gris, 0, -0.5, 0, hombroDer);
pieza(new THREE.SphereGeometry(0.2, 16, 8), rojo, 0, -1.05, 0, hombroDer);


let inicioBrinco = -10;
 
addEventListener('keydown', (e) => {
  if (e.key === 'ArrowRight') robot.position.x += 0.5;
  if (e.key === 'ArrowLeft') robot.position.x -= 0.5;
  if (e.key === 'ArrowUp') robot.position.z -= 0.5;
  if (e.key === 'ArrowDown') robot.position.z += 0.5;
  if (e.key === ' ') inicioBrinco = reloj.getElapsedTime();
});
 
animaciones.push((t) => {
  const s = t - inicioBrinco; 
  robot.position.y = s < 0.6 ? Math.sin((s / 0.6) * Math.PI) * 1.5 : 0;
  datos['Traslación'] = vec(robot.position);
});
addEventListener('keydown', (e) => {
  if (e.key === '+') robot.scale.multiplyScalar(1.1);
  if (e.key === '-') robot.scale.multiplyScalar(0.9);
});
 
animaciones.push((t) => {
  torso.scale.set(1 + 0.04 * Math.sin(t * 2), 1 + 0.08 * Math.sin(t * 2), 1);
  datos['Escala'] = vec(robot.scale);
});
  

// Teclas Q y E: girar al robot sobre el eje Y (22.5° cada vez)
addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() === 'q') robot.rotation.y += Math.PI / 8;
  if (e.key.toLowerCase() === 'e') robot.rotation.y -= Math.PI / 8;
});
 
animaciones.push((t) => {
  // Saludar: el brazo gira alrededor del HOMBRO, no del centro del brazo
  // hombroDer.rotation.z = 2.4 + 0.4 * Math.sin(t * 6);
  // La cabeza voltea a los lados (gira sobre su propio eje Y)
  //cabeza.rotation.y = 0.5 * Math.sin(t);
  const grados = THREE.MathUtils.radToDeg(robot.rotation.y);
  datos['Rotación Y'] = `${grados.toFixed(1)}°`;
});

addEventListener('keydown', (p) => {
  if (p.key.toLowerCase() === 'p') robot.rotation.z = 2.4 + 6.0 * Math.sin(t * 1);
});
// Teclas Q y E: girar al robot sobre el eje Y (22.5° cada vez)
animaciones.push((t) => {


});

let gelatina = false;
addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() === 'g') gelatina = !gelatina;
});
 
cuerpoRobot.matrixAutoUpdate = false; 
 
animaciones.push((t) => {
  const k = gelatina ? 0.4 * Math.sin(t * 5) : 0;
  cuerpoRobot.matrix.set(
    1, k, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1
  );
  cuerpoRobot.matrixWorldNeedsUpdate = true;
  datos['Sesgado k'] = k.toFixed(2);
});

// Girar como rueda con la tecla G
let girandoRueda = false;

addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'g') {
        girandoRueda = !girandoRueda;
    }
});

animaciones.push((t) => {
    if (girandoRueda) {
        robot.rotation.x += 0.05;
    }
});


let perspective = false;



addEventListener('keydown', (e) => {
    if (e.key.toLowerCase() === 'p') {
        if (!perspective) {
            perspective = new THREE.PerspectiveCamera(50, innerWidth / innerHeight, 0.1, 100);
            camara.position.set(8, 25, 0);
        } else {
            perspective = false;
            camara.position.set(6, 5, 10); 
        }
    }
});


